import pyxel

pyxel.init(128, 128, title="Nuit du c0de")
tirs_liste=[]
vaisseau_x = 60
vaisseau_y = 60
pyxel.load("3.pyxres")
def vaisseau_mouvement(x, y):
    """déplacement avec les touches de directions"""

    if pyxel.btn(pyxel.KEY_RIGHT):
        if (x < 120) :
            x = x + 1
    if pyxel.btn(pyxel.KEY_LEFT):
        if (x > 0) :
            x = x - 1
    if pyxel.btn(pyxel.KEY_DOWN):
        if (y < 120) :
            y = y + 1
    if pyxel.btn(pyxel.KEY_UP):
        if (y > 0) :
            y = y - 1
    return x, y

def tirs_creation(x, y, tirs_liste):
    """création d'un tir avec la barre d'espace"""

    # btnr pour eviter les tirs multiples
    if pyxel.btnr(pyxel.KEY_SPACE):
        tirs_liste.append([x-1 , y-7])
    return tirs_liste


def tirs_deplacement(tirs_liste):
    """déplacement des tirs vers le haut et suppression s'ils sortent du cadre"""

    for tir in tirs_liste:
        tir[1] -= 1
        if  tir[1]<-8:
            tirs_liste.remove(tir)
    return tirs_liste



def actualisation():
    global vaisseau_x, vaisseau_y, tirs_liste

     # mise à jour de la position du vaisseau
    vaisseau_x, vaisseau_y = vaisseau_mouvement(vaisseau_x, vaisseau_y)

        # creation des tirs en fonction de la position du vaisseau
    tirs_liste = tirs_creation(vaisseau_x, vaisseau_y, tirs_liste)

        # mise a jour des positions des tirs
    tirs_liste = tirs_deplacement(tirs_liste)


def objet():
    """création des objets """

    pyxel.cls(0)

    #pyxel.rect(vaisseau_x, vaisseau_y, 8, 8, 1)
    pyxel.blt(vaisseau_x, vaisseau_y, 0, 0, 0, 9, 7)
    for tir in tirs_liste:
                pyxel.blt(tir[0], tir[1], 0, 9, 0, 10, 8)
pyxel.run(actualisation, objet)


for tir in tirs_liste:
            pyxel.blt(tir[0], tir[1], 0, 9, 0, 10, 8)


