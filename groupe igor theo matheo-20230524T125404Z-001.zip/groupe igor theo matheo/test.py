import pyxel
import random

pyxel.init(128, 128, title="NDC 2023", fps=60)

tirs_liste = []
vaisseau_x = 64
vaisseau_y = 64
ennemis_liste = []
vies = 3
score = 0

def afficher_score():
    pyxel.text(120, 120, f"Score: {score}", 7)

def vaisseau_mouvement(x, y):
    """Déplacement avec les touches de direction"""
    if pyxel.btn(pyxel.KEY_RIGHT) and x < 120:
        x += 1
    if pyxel.btn(pyxel.KEY_LEFT) and x > 0:
        x -= 1
    if pyxel.btn(pyxel.KEY_DOWN) and y < 120:
        y += 1
    if pyxel.btn(pyxel.KEY_UP) and y > 0:
        y -= 1
    return x, y

def tirs_creation(x, y, tirs_liste):
    """Création d'un tir avec la barre d'espace"""
    if pyxel.btnr(pyxel.KEY_SPACE):
        tirs_liste.append([x - 1, y - 7])
    return tirs_liste

def tirs_deplacement(tirs_liste):
    """Déplacement des tirs vers le haut et suppression s'ils sortent du cadre"""
    for tir in tirs_liste:
        tir[1] -= 1
        if tir[1] < -8:
            tirs_liste.remove(tir)
    return tirs_liste

def ennemis_creation(ennemis_liste):
    """Création aléatoire des ennemis"""
    if pyxel.frame_count % 30 == 0:
        ennemis_liste.append([random.randint(0, 120), 0])
    return ennemis_liste

def vaisseau_suppression(vies):
    """Disparition du vaisseau et d'un ennemi en cas de contact"""
    global score
    for ennemi in ennemis_liste:
        if (
            ennemi[0] <= vaisseau_x + 8
            and ennemi[1] <= vaisseau_y + 8
            and ennemi[0] + 8 >= vaisseau_x
            and ennemi[1] + 8 >= vaisseau_y
        ):
            ennemis_liste.remove(ennemi)
            vies -= 1
    return vies

def ennemis_suppression():
    """Disparition d'un ennemi et d'un tir en cas de contact"""
    global score
    for ennemi in ennemis_liste:
        for tir in tirs_liste:
            if (
                ennemi[0] <= tir[0] + 1
                and ennemi[0] + 11 >= tir[0]
                and ennemi[1] + 11 >= tir[1]
            ):
                ennemis_liste.remove(ennemi)
                tirs_liste.remove(tir)
                score += 10

def ennemis_deplacement(ennemis_liste):
    """Déplacement des ennemis vers le haut et suppression s'ils sortent du cadre"""
    for ennemi in ennemis_liste:
        ennemi[1] += 1
        if ennemi[1] > 128:
            ennemis_liste.remove(ennemi)
    return ennemis_liste

def actualisation():
    """Mise à jour des variables (30 fois par seconde)"""
    global vaisseau_x, vaisseau_y, tirs_liste, ennemis_liste, vies

    vaisseau_x, vaisseau_y = vaisseau_mouvement(vaisseau_x, vaisseau_y)
    tirs_liste = tirs_creation(vaisseau_x, vaisseau_y, tirs_liste)
    tirs_liste = tirs_deplacement(tirs_liste)
    ennemis_liste = ennemis_creation(ennemis_liste)
    ennemis_liste = ennemis_deplacement(ennemis_liste)
    ennemis_suppression()
    vies = vaisseau_suppression(vies)

def objet():
    """Création des objets"""
    pyxel.cls(0)

    if vies > 0:
        pyxel.blt(vaisseau_x, vaisseau_y, 0, 0, 0, 9, 7)
        for tir in tirs_liste:
            pyxel.blt(tir[0], tir[1], 0, 9, 0, 10, 7)
        for ennemi in ennemis_liste:
            pyxel.blt(ennemi[0], ennemi[1], 0, 20, 11, 11, 11)
    else:
        pyxel.text(50, 50, "Game Over", 8)

    afficher_score()

afficher_score()  # Afficher le score initial
pyxel.run(actualisation, objet)
